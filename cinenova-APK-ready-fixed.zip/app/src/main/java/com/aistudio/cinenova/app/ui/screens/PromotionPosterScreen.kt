package com.aistudio.cinenova.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PromotionPosterScreen(
  repository: CineNovaRepository,
  currentUserId: String,
  onBackClick: () -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val campaign = repository.defaultCampaign

  var secondsLeft by remember { mutableIntStateOf(campaign.durationSeconds) }
  var isScreenActive by remember { mutableStateOf(true) }
  var isCompleted by remember { mutableStateOf(false) }
  var isClaimed by remember { mutableStateOf(false) }
  var isClaiming by remember { mutableStateOf(false) }

  // Check if already claimed today
  val todayKey = remember { repository.getTodayDateKey() }
  val taskCompletions by repository.taskCompletions.collectAsState()
  val completionKey = "${currentUserId}_task_promo_poster_$todayKey"
  val existingCompletion = taskCompletions[completionKey]

  LaunchedEffect(existingCompletion) {
    if (existingCompletion?.claimed == true) {
      isClaimed = true
      isCompleted = true
      secondsLeft = 0
    }
  }

  // Lifecycle observer: pause timer if app is sent to background
  val lifecycleOwner = LocalLifecycleOwner.current
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_RESUME -> isScreenActive = true
        Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> isScreenActive = false
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  // Active View Countdown Timer (30s)
  LaunchedEffect(isScreenActive, isCompleted, secondsLeft) {
    if (isScreenActive && !isCompleted && secondsLeft > 0) {
      delay(1000L)
      secondsLeft -= 1
      if (secondsLeft <= 0) {
        isCompleted = true
        // Record task progress
        repository.recordTaskProgress(currentUserId, "task_promo_poster", 1)
      }
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .testTag("promotion_poster_screen")
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(bottom = 32.dp)
    ) {
      // Top App Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        IconButton(
          onClick = onBackClick,
          modifier = Modifier.size(40.dp)
        ) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }

        Surface(
          shape = RoundedCornerShape(16.dp),
          color = CineDarkSurfaceVariant,
          border = androidx.compose.foundation.BorderStroke(1.dp, CineGold)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = CineGold, modifier = Modifier.size(16.dp))
            Text(
              text = "+${campaign.reward} Coins",
              color = CineGoldLight,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }
      }

      // Poster Image Container
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp)
          .clip(RoundedCornerShape(16.dp))
          .background(CineDarkSurface)
      ) {
        AsyncImage(
          model = ImageRequest.Builder(context)
            .data(campaign.poster)
            .crossfade(true)
            .build(),
          contentDescription = campaign.title,
          contentScale = ContentScale.FillWidth,
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 360.dp)
        )

        // Verified Timer Floating Badge
        Surface(
          shape = RoundedCornerShape(24.dp),
          color = Color.Black.copy(alpha = 0.85f),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isCompleted) CineGold else CineRed
          ),
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(12.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(
              imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.Timer,
              contentDescription = null,
              tint = if (isCompleted) CineGold else CineRed,
              modifier = Modifier.size(16.dp)
            )
            Text(
              text = if (isCompleted) "Verified" else "${secondsLeft}s left",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Campaign Information
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = CineRed
          ) {
            Text(
              text = "OFFICIAL SPONSOR",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Text(text = campaign.sponsor, color = CineTextSecondary, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = campaign.title,
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 20.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = campaign.description,
          color = CineTextSecondary,
          fontSize = 13.sp,
          lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Progress or Claim section
        if (isClaimed) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = CineDarkSurfaceVariant,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CineGold, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Reward already claimed today (+${campaign.reward} Coins)",
                color = CineGoldLight,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              )
            }
          }
        } else {
          // Claim Reward Button
          Button(
            onClick = {
              if (isCompleted && !isClaiming) {
                isClaiming = true
                scope.launch {
                  val res = repository.claimTaskReward(currentUserId, "task_promo_poster")
                  isClaiming = false
                  res.fold(
                    onSuccess = { awarded ->
                      isClaimed = true
                      Toast.makeText(context, "+$awarded Coins claimed successfully!", Toast.LENGTH_LONG).show()
                    },
                    onFailure = { err ->
                      Toast.makeText(context, err.message ?: "Failed to claim", Toast.LENGTH_SHORT).show()
                    }
                  )
                }
              }
            },
            enabled = isCompleted && !isClaiming,
            colors = ButtonDefaults.buttonColors(
              containerColor = CineGold,
              disabledContainerColor = CineDarkSurfaceVariant
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("claim_promo_reward_button")
          ) {
            if (isClaiming) {
              CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
            } else {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
              ) {
                Icon(
                  imageVector = Icons.Default.MonetizationOn,
                  contentDescription = null,
                  tint = if (isCompleted) Color.Black else CineTextMuted
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (isCompleted) "Claim +${campaign.reward} Coins Now" else "View for ${secondsLeft}s to Unlock Reward",
                  color = if (isCompleted) Color.Black else CineTextMuted,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Timer verification rules notice
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CineDarkSurfaceVariant.copy(alpha = 0.5f))
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Security, contentDescription = null, tint = CineGold, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Anti-Abuse Verification: The timer counts down only while this poster is actively in view. Exiting or backgrounding pauses the verification.",
            color = CineTextMuted,
            fontSize = 11.sp,
            lineHeight = 15.sp
          )
        }
      }
    }
  }
}
