package com.aistudio.cinenova.app.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlayerState(
  val isPlaying: Boolean = false,
  val currentPosition: Long = 0L,
  val duration: Long = 0L,
  val isBuffering: Boolean = false,
  val isEnded: Boolean = false,
  val error: String? = null,
  val isMuted: Boolean = false
)

@OptIn(UnstableApi::class)
class ExoPlayerManager(private val context: Context) {
  var player: ExoPlayer? = null
    private set

  private val _state = MutableStateFlow(PlayerState())
  val state: StateFlow<PlayerState> = _state.asStateFlow()

  private var positionPollingJob: Job? = null
  private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

  fun initializePlayer(videoUrl: String, startPositionMs: Long = 0L) {
    release()

    val exoPlayer = ExoPlayer.Builder(context).build().apply {
      val mediaItem = MediaItem.fromUri(Uri.parse(videoUrl))
      setMediaItem(mediaItem)
      prepare()
      if (startPositionMs > 0) {
        seekTo(startPositionMs)
      }
      playWhenReady = true
    }

    exoPlayer.addListener(object : Player.Listener {
      override fun onPlaybackStateChanged(playbackState: Int) {
        val isBuffering = playbackState == Player.STATE_BUFFERING
        val isEnded = playbackState == Player.STATE_ENDED
        _state.value = _state.value.copy(
          isBuffering = isBuffering,
          isEnded = isEnded,
          duration = exoPlayer.duration.coerceAtLeast(0L),
          error = null
        )
      }

      override fun onIsPlayingChanged(isPlaying: Boolean) {
        _state.value = _state.value.copy(isPlaying = isPlaying)
      }

      override fun onPlayerError(error: PlaybackException) {
        _state.value = _state.value.copy(
          error = "Stream error: ${error.localizedMessage ?: "Unable to play video"}",
          isBuffering = false
        )
      }
    })

    player = exoPlayer
    startPositionPolling()
  }

  private fun startPositionPolling() {
    positionPollingJob?.cancel()
    positionPollingJob = scope.launch {
      while (isActive) {
        player?.let { p ->
          _state.value = _state.value.copy(
            currentPosition = p.currentPosition.coerceAtLeast(0L),
            duration = p.duration.coerceAtLeast(0L)
          )
        }
        delay(500)
      }
    }
  }

  fun play() {
    player?.play()
  }

  fun pause() {
    player?.pause()
  }

  fun togglePlayPause() {
    val p = player ?: return
    if (p.isPlaying) p.pause() else p.play()
  }

  fun seekTo(positionMs: Long) {
    player?.seekTo(positionMs)
  }

  fun forward10Seconds() {
    val p = player ?: return
    p.seekTo((p.currentPosition + 10000L).coerceAtMost(p.duration))
  }

  fun rewind10Seconds() {
    val p = player ?: return
    p.seekTo((p.currentPosition - 10000L).coerceAtLeast(0L))
  }

  fun toggleMute() {
    val p = player ?: return
    val newMute = !_state.value.isMuted
    p.volume = if (newMute) 0f else 1f
    _state.value = _state.value.copy(isMuted = newMute)
  }

  fun retry(videoUrl: String) {
    initializePlayer(videoUrl, _state.value.currentPosition)
  }

  fun release() {
    positionPollingJob?.cancel()
    positionPollingJob = null
    player?.release()
    player = null
    _state.value = PlayerState()
  }
}
