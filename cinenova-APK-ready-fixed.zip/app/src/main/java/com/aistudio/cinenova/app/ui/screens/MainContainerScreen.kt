package com.aistudio.cinenova.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.data.repository.AuthRepository
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.components.CineTopBar
import com.aistudio.cinenova.app.ui.navigation.BottomTab
import com.aistudio.cinenova.app.ui.theme.*

@Composable
fun MainContainerScreen(
  authRepository: AuthRepository,
  repository: CineNovaRepository,
  onMovieClick: (String) -> Unit,
  onPlayClick: (String) -> Unit,
  onPromoClick: () -> Unit,
  onSearchClick: () -> Unit,
  onUploadClick: () -> Unit,
  onWatchlistClick: () -> Unit,
  onWatchHistoryClick: () -> Unit,
  onCoinHistoryClick: () -> Unit,
  onSettingsClick: () -> Unit,
  onLogout: () -> Unit
) {
  var selectedTab by remember { mutableStateOf(BottomTab.HOME) }
  val currentUser by authRepository.currentUser.collectAsState()
  val coinBalance by repository.coinBalance.collectAsState()

  val userId = currentUser?.userId ?: "guest"
  val userName = currentUser?.name ?: "Streamer"

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    topBar = {
      // Show CineTopBar only on tabs where appropriate (Home, Movies, Tasks)
      if (selectedTab != BottomTab.SHORTS) {
        CineTopBar(
          coinBalance = coinBalance.balance,
          onCoinClick = { selectedTab = BottomTab.TASKS },
          onSearchClick = onSearchClick,
          onUploadClick = onUploadClick
        )
      }
    },
    bottomBar = {
      NavigationBar(
        containerColor = CineDarkSurface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("bottom_nav_bar")
      ) {
        BottomTab.entries.forEach { tab ->
          val isSelected = selectedTab == tab
          val icon = when (tab) {
            BottomTab.HOME -> if (isSelected) Icons.Filled.Home else Icons.Outlined.Home
            BottomTab.MOVIES -> if (isSelected) Icons.Filled.Movie else Icons.Outlined.Movie
            BottomTab.SHORTS -> if (isSelected) Icons.Filled.PlayCircleFilled else Icons.Outlined.PlayCircleOutline
            BottomTab.TASKS -> if (isSelected) Icons.Filled.MonetizationOn else Icons.Outlined.MonetizationOn
            BottomTab.PROFILE -> if (isSelected) Icons.Filled.Person else Icons.Outlined.Person
          }
          val activeColor = if (tab == BottomTab.TASKS) CineGold else CineRed

          NavigationBarItem(
            selected = isSelected,
            onClick = { selectedTab = tab },
            icon = {
              Icon(
                imageVector = icon,
                contentDescription = tab.title,
                tint = if (isSelected) activeColor else CineTextSecondary
              )
            },
            label = {
              Text(
                text = tab.title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else CineTextSecondary
              )
            },
            colors = NavigationBarItemDefaults.colors(
              indicatorColor = activeColor.copy(alpha = 0.2f),
              selectedIconColor = activeColor,
              unselectedIconColor = CineTextSecondary
            ),
            modifier = Modifier.testTag("bottom_tab_${tab.name.lowercase()}")
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(CineDarkBackground)
        .padding(
          top = if (selectedTab == BottomTab.SHORTS) 0.dp else innerPadding.calculateTopPadding(),
          bottom = innerPadding.calculateBottomPadding()
        )
    ) {
      when (selectedTab) {
        BottomTab.HOME -> {
          HomeScreen(
            repository = repository,
            currentUserId = userId,
            onMovieClick = onMovieClick,
            onPlayClick = onPlayClick,
            onShortsClick = { selectedTab = BottomTab.SHORTS }
          )
        }
        BottomTab.MOVIES -> {
          MoviesScreen(
            repository = repository,
            onMovieClick = onMovieClick
          )
        }
        BottomTab.SHORTS -> {
          ShortsScreen(
            repository = repository,
            currentUserId = userId,
            currentUserName = userName
          )
        }
        BottomTab.TASKS -> {
          TasksScreen(
            repository = repository,
            currentUserId = userId,
            onOpenPromoCampaign = onPromoClick,
            onOpenCoinHistory = onCoinHistoryClick
          )
        }
        BottomTab.PROFILE -> {
          ProfileScreen(
            authRepository = authRepository,
            repository = repository,
            onOpenMovie = onMovieClick,
            onOpenWatchlist = onWatchlistClick,
            onOpenWatchHistory = onWatchHistoryClick,
            onOpenCoinHistory = onCoinHistoryClick,
            onOpenUploadVideo = onUploadClick,
            onOpenSettings = onSettingsClick,
            onLogout = onLogout
          )
        }
      }
    }
  }
}
