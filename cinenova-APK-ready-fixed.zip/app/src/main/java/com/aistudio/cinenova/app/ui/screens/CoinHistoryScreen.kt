package com.aistudio.cinenova.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CoinHistoryScreen(
  repository: CineNovaRepository,
  currentUserId: String,
  onBackClick: () -> Unit
) {
  val coinTransactions by repository.coinTransactions.collectAsState()
  val coinBalance by repository.coinBalance.collectAsState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .statusBarsPadding()
      .testTag("coin_history_screen")
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBackClick) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Coin Ledger",
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 20.sp
        )
      }

      Surface(
        shape = RoundedCornerShape(16.dp),
        color = CineDarkSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, CineGold.copy(alpha = 0.5f))
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = CineGold, modifier = Modifier.size(16.dp))
          Text(
            text = "${coinBalance.balance}",
            color = CineGoldLight,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
        }
      }
    }

    if (coinTransactions.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "No coin transactions yet.\nComplete daily tasks or view promotional campaigns to earn coins.",
          color = CineTextMuted,
          fontSize = 14.sp,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center,
          lineHeight = 22.sp
        )
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(coinTransactions, key = { it.transactionId }) { txn ->
          val dateFormatted = remember(txn.timestamp) {
            val sdf = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault())
            sdf.format(Date(txn.timestamp))
          }

          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(CineGold.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = CineGold, modifier = Modifier.size(22.dp))
              }

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = txn.reason,
                  color = Color.White,
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 14.sp
                )
                Text(
                  text = "Ref: ${txn.transactionId}",
                  color = CineTextMuted,
                  fontSize = 10.sp
                )
                Text(
                  text = dateFormatted,
                  color = CineTextSecondary,
                  fontSize = 11.sp
                )
              }

              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = if (txn.amount >= 0) "+${txn.amount}" else "${txn.amount}",
                  color = if (txn.amount >= 0) CineGoldLight else CineError,
                  fontWeight = FontWeight.Black,
                  fontSize = 16.sp
                )
                Text(
                  text = "Bal: ${txn.balanceAfter}",
                  color = CineTextMuted,
                  fontSize = 11.sp
                )
              }
            }
          }
        }
      }
    }
  }
}
