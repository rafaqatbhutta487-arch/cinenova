package com.aistudio.cinenova.app.data.remote

import android.content.Context
import android.net.Uri
import android.util.Log
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Minimal client for Supabase Storage's REST API — used instead of
 * Firebase Storage because Firebase Storage requires the Blaze
 * (billing) plan, and Supabase's free tier needs no card.
 *
 * IMPORTANT: replace SUPABASE_URL / SUPABASE_ANON_KEY with your own
 * project's values (Settings -> API Keys in the Supabase dashboard).
 * The anon/publishable key is safe to ship in the app; it only has the
 * permissions your bucket policies allow (public bucket = public read,
 * and this key can also write since the bucket policies allow it).
 */
object SupabaseStorage {

  // TODO: put your own project's values here
  private const val SUPABASE_URL = "https://wvhhkipfbmfkvzpqoyvi.supabase.co"
  private const val SUPABASE_ANON_KEY = "sb_publishable_QHeXhDJpwEDv29GAv1vy_Q_jvBNfkvd"

  private const val VIDEO_BUCKET = "cinenova-videos"

  private val client = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(10, TimeUnit.MINUTES) // videos can be large / slow to upload
    .readTimeout(60, TimeUnit.SECONDS)
    .build()

  /**
   * Uploads [uri]'s bytes to `bucket/path` in Supabase Storage and
   * returns the public download URL on success.
   */
  fun uploadFile(
    context: Context,
    uri: Uri,
    path: String,
    mimeType: String,
    bucket: String = VIDEO_BUCKET
  ): Result<String> {
    return try {
      val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: return Result.failure(IOException("Could not read file"))

      val mediaType = mimeType.toMediaTypeOrNull()
      val body = bytes.toRequestBody(mediaType)

      val uploadUrl = "$SUPABASE_URL/storage/v1/object/$bucket/$path"
      val request = Request.Builder()
        .url(uploadUrl)
        .addHeader("apikey", SUPABASE_ANON_KEY)
        .addHeader("Authorization", "Bearer $SUPABASE_ANON_KEY")
        .addHeader("x-upsert", "true")
        .post(body)
        .build()

      client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
          val errBody = response.body?.string() ?: ""
          Log.e("SupabaseStorage", "Upload failed: ${response.code} $errBody")
          return Result.failure(IOException("Upload failed (${response.code}): $errBody"))
        }
      }

      val publicUrl = "$SUPABASE_URL/storage/v1/object/public/$bucket/$path"
      Result.success(publicUrl)
    } catch (e: Exception) {
      Log.e("SupabaseStorage", "Upload error: ${e.message}")
      Result.failure(e)
    }
  }
}
