package com.aistudio.cinenova.app.ui.screens

import android.content.Intent
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.aistudio.cinenova.app.data.model.Comment
import com.aistudio.cinenova.app.data.model.ShortVideo
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.player.ExoPlayerManager
import com.aistudio.cinenova.app.ui.components.CommentBottomSheet
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun ShortsScreen(
  repository: CineNovaRepository,
  currentUserId: String,
  currentUserName: String
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val shorts by repository.shorts.collectAsState()
  val userLikes by repository.userLikes.collectAsState()

  if (shorts.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(CineDarkBackground),
      contentAlignment = Alignment.Center
    ) {
      Text("No shorts available at this time", color = CineTextSecondary)
    }
    return
  }

  val pagerState = rememberPagerState(pageCount = { shorts.size })
  var activeCommentShortId by remember { mutableStateOf<String?>(null) }
  var commentsList by remember { mutableStateOf<List<Comment>>(emptyList()) }

  // Increment watch short task after watching
  LaunchedEffect(pagerState.currentPage) {
    repository.recordTaskProgress(currentUserId, "task_watch_short", 1)
    val currentShort = shorts.getOrNull(pagerState.currentPage)
    currentShort?.let {
      delay(3000)
      repository.recordView(it.shortId, isShort = true)
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color.Black)
      .testTag("shorts_screen")
  ) {
    VerticalPager(
      state = pagerState,
      modifier = Modifier.fillMaxSize()
    ) { page ->
      val short = shorts[page]
      val isPageActive = pagerState.currentPage == page

      ShortPageItem(
        short = short,
        isActive = isPageActive,
        isLiked = userLikes.contains(short.shortId),
        onToggleLike = {
          scope.launch {
            repository.toggleLike(currentUserId, short.shortId, "short")
          }
        },
        onOpenComments = {
          activeCommentShortId = short.shortId
          scope.launch {
            commentsList = repository.getComments(short.shortId)
          }
        },
        onShare = {
          val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Watch this CineShort: \"${short.title}\" on CineNova! ${short.videoUrl}")
            type = "text/plain"
          }
          context.startActivity(Intent.createChooser(shareIntent, "Share Short"))
        }
      )
    }

    // Comments Sheet
    if (activeCommentShortId != null) {
      CommentBottomSheet(
        comments = commentsList,
        currentUserId = currentUserId,
        onDismiss = { activeCommentShortId = null },
        onAddComment = { text ->
          scope.launch {
            val res = repository.addComment(currentUserId, currentUserName, activeCommentShortId!!, text)
            res.onSuccess {
              commentsList = listOf(it) + commentsList
            }
          }
        },
        onDeleteComment = { commentId ->
          scope.launch {
            repository.deleteComment(commentId)
            commentsList = commentsList.filterNot { it.commentId == commentId }
          }
        }
      )
    }
  }
}

@OptIn(UnstableApi::class)
@Composable
private fun ShortPageItem(
  short: ShortVideo,
  isActive: Boolean,
  isLiked: Boolean,
  onToggleLike: () -> Unit,
  onOpenComments: () -> Unit,
  onShare: () -> Unit
) {
  val context = LocalContext.current
  val playerManager = remember { ExoPlayerManager(context) }
  val playerState by playerManager.state.collectAsState()
  var isFollowing by remember { mutableStateOf(false) }

  // Manage playback lifecycle on pager page switch
  LaunchedEffect(isActive) {
    if (isActive) {
      playerManager.initializePlayer(short.videoUrl)
    } else {
      playerManager.pause()
      playerManager.release()
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      playerManager.release()
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null
      ) {
        playerManager.togglePlayPause()
      }
  ) {
    // Video Player
    AndroidView(
      factory = { ctx ->
        // Inflated from XML so surface_type="texture_view" is applied
        // (fixes black video frame with working audio inside Compose).
        (android.view.LayoutInflater.from(ctx)
          .inflate(com.aistudio.cinenova.app.R.layout.exo_player_view, null) as PlayerView).apply {
          player = playerManager.player
          layoutParams = android.view.ViewGroup.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.MATCH_PARENT
          )
        }
      },
      update = { view ->
        view.player = playerManager.player
      },
      modifier = Modifier.fillMaxSize()
    )

    // Paused Icon indicator
    if (!playerState.isPlaying && !playerState.isBuffering) {
      Box(
        modifier = Modifier
          .size(68.dp)
          .clip(CircleShape)
          .background(Color.Black.copy(alpha = 0.5f))
          .align(Alignment.Center),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = "Paused", tint = Color.White, modifier = Modifier.size(40.dp))
      }
    }

    // Buffering indicator
    if (playerState.isBuffering) {
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
      ) {
        CircularProgressIndicator(color = CineRed, modifier = Modifier.size(44.dp))
      }
    }

    // Overlay Gradients
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(180.dp)
        .align(Alignment.BottomCenter)
        .background(
          Brush.verticalGradient(
            listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))
          )
        )
    )

    // Side Actions Bar (Like, Comment, Share, Views)
    Column(
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(end = 12.dp, bottom = 100.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Like
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
          onClick = onToggleLike,
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.4f))
            .testTag("short_like_button")
        ) {
          Icon(
            imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Like Short",
            tint = if (isLiked) CineRed else Color.White,
            modifier = Modifier.size(26.dp)
          )
        }
        Text(
          text = "${short.likes}",
          color = Color.White,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // Comments
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
          onClick = onOpenComments,
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.4f))
            .testTag("short_comment_button")
        ) {
          Icon(
            imageVector = Icons.Default.Comment,
            contentDescription = "Comment",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
        }
        Text(
          text = "${short.commentsCount}",
          color = Color.White,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // Share
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
          onClick = onShare,
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.4f))
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
        }
        Text(
          text = "Share",
          color = Color.White,
          fontSize = 10.sp
        )
      }

      // View count indicator
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Visibility, contentDescription = null, tint = CineGoldLight, modifier = Modifier.size(20.dp))
        Text(
          text = "${short.views}",
          color = CineGoldLight,
          fontSize = 10.sp
        )
      }
    }

    // Bottom Short Info: Creator, Title, Description
    Column(
      modifier = Modifier
        .align(Alignment.BottomStart)
        .fillMaxWidth(0.78f)
        .padding(start = 16.dp, bottom = 100.dp)
    ) {
      // Creator Row
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(CineRed),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = short.creatorName.take(1),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }

        Text(
          text = "@${short.creatorName}",
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp
        )

        Button(
          onClick = { isFollowing = !isFollowing },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isFollowing) CineDarkSurfaceVariant else CineRed
          ),
          shape = RoundedCornerShape(14.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
          modifier = Modifier.height(28.dp)
        ) {
          Text(
            text = if (isFollowing) "Following" else "Follow",
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = short.title,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = short.description,
        color = CineTextSecondary,
        fontSize = 12.sp,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )
    }
  }
}
