package com.aistudio.cinenova.app.ui.screens

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.player.ExoPlayerManager
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerScreen(
  movieId: String,
  repository: CineNovaRepository,
  currentUserId: String,
  onBackClick: () -> Unit
) {
  val context = LocalContext.current
  val activity = context as? Activity
  val scope = rememberCoroutineScope()

  val movies by repository.movies.collectAsState()
  val watchHistory by repository.watchHistory.collectAsState()
  val movie = remember(movies, movieId) { movies.find { it.movieId == movieId } }

  val playerManager = remember { ExoPlayerManager(context) }
  val playerState by playerManager.state.collectAsState()

  var isFullscreen by remember { mutableStateOf(false) }
  var showControls by remember { mutableStateOf(true) }
  var hasShownResumePrompt by remember { mutableStateOf(false) }
  var resumePositionMs by remember { mutableStateOf(0L) }

  // Check if there is previous watch history to resume
  LaunchedEffect(movieId, watchHistory) {
    if (!hasShownResumePrompt) {
      val existingHistory = watchHistory.find { it.videoId == movieId }
      if (existingHistory != null && existingHistory.positionSeconds > 5 && existingHistory.progressPercentage < 95) {
        resumePositionMs = existingHistory.positionSeconds * 1000L
      }
      hasShownResumePrompt = true
    }
  }

  // Initialize playback
  LaunchedEffect(movie?.videoUrl) {
    movie?.let { m ->
      playerManager.initializePlayer(m.videoUrl, resumePositionMs)
      // Record view after 5 seconds
      delay(5000)
      repository.recordView(m.movieId, isShort = false)
    }
  }

  // Auto-hide controls after 4 seconds of inactivity
  LaunchedEffect(showControls, playerState.isPlaying) {
    if (showControls && playerState.isPlaying) {
      delay(4000)
      showControls = false
    }
  }

  // Periodic watch progress saving (every 5 seconds)
  LaunchedEffect(playerState.currentPosition) {
    if (playerState.currentPosition > 2000 && movie != null) {
      val posSec = playerState.currentPosition / 1000L
      val durSec = if (playerState.duration > 0) playerState.duration / 1000L else movie.durationSeconds
      repository.updateWatchProgress(currentUserId, movie, posSec, durSec)
    }
  }

  // Save on dispose / stop
  DisposableEffect(Unit) {
    onDispose {
      val currentPos = playerManager.state.value.currentPosition / 1000L
      val dur = if (playerManager.state.value.duration > 0) playerManager.state.value.duration / 1000L else (movie?.durationSeconds ?: 0L)
      if (currentPos > 0 && movie != null) {
        scope.launch {
          repository.updateWatchProgress(currentUserId, movie, currentPos, dur)
        }
      }
      activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
      playerManager.release()
    }
  }

  fun toggleFullscreen() {
    val nextFs = !isFullscreen
    isFullscreen = nextFs
    activity?.requestedOrientation = if (nextFs) {
      ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    } else {
      ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }
  }

  if (movie == null) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black),
      contentAlignment = Alignment.Center
    ) {
      Text("Video not found", color = Color.White)
    }
    return
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color.Black)
      .testTag("video_player_screen")
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null
      ) {
        showControls = !showControls
      }
  ) {
    // Media3 Player View
    AndroidView(
      factory = { ctx ->
        // Inflated from XML (not `PlayerView(ctx)`) so we can force
        // surface_type="texture_view". The default SurfaceView doesn't
        // composite correctly inside Jetpack Compose on some devices,
        // which is what causes audio to play with a black video frame.
        (android.view.LayoutInflater.from(ctx)
          .inflate(com.aistudio.cinenova.app.R.layout.exo_player_view, null) as PlayerView).apply {
          player = playerManager.player
          layoutParams = android.view.ViewGroup.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.MATCH_PARENT
          )
        }
      },
      update = { view ->
        view.player = playerManager.player
      },
      modifier = Modifier.fillMaxSize()
    )

    // Buffering indicator
    if (playerState.isBuffering) {
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
      ) {
        CircularProgressIndicator(
          color = CineRed,
          strokeWidth = 4.dp,
          modifier = Modifier.size(54.dp)
        )
      }
    }

    // Error banner with retry
    if (playerState.error != null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black.copy(alpha = 0.8f))
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = CineError, modifier = Modifier.size(48.dp))
          Text(
            text = playerState.error ?: "Stream error",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
          Button(
            onClick = { playerManager.retry(movie.videoUrl) },
            colors = ButtonDefaults.buttonColors(containerColor = CineRed)
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Retry Stream", color = Color.White)
          }
        }
      }
    }

    // Resume Watching Notification Toast Banner
    if (resumePositionMs > 0 && playerState.currentPosition < 3000) {
      Surface(
        color = CineDarkSurface.copy(alpha = 0.9f),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CineGold),
        modifier = Modifier
          .align(Alignment.TopCenter)
          .statusBarsPadding()
          .padding(top = 16.dp)
      ) {
        Text(
          text = "Resumed from ${formatTime(resumePositionMs)}",
          color = CineGoldLight,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
        )
      }
    }

    // Overlay Controls
    AnimatedVisibility(
      visible = showControls,
      enter = fadeIn(),
      exit = fadeOut(),
      modifier = Modifier.fillMaxSize()
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              listOf(
                Color.Black.copy(alpha = 0.7f),
                Color.Transparent,
                Color.Black.copy(alpha = 0.85f)
              )
            )
          )
      ) {
        // Top Bar: Back, Title, Fullscreen toggle
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          IconButton(
            onClick = onBackClick,
            modifier = Modifier.testTag("player_back_button")
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }

          Text(
            text = movie.title,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            maxLines = 1,
            modifier = Modifier
              .weight(1f)
              .padding(horizontal = 8.dp)
          )

          Row {
            IconButton(onClick = { playerManager.toggleMute() }) {
              Icon(
                imageVector = if (playerState.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                contentDescription = "Mute",
                tint = Color.White
              )
            }
            IconButton(
              onClick = { toggleFullscreen() },
              modifier = Modifier.testTag("player_fullscreen_button")
            ) {
              Icon(
                imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                contentDescription = "Fullscreen",
                tint = Color.White
              )
            }
          }
        }

        // Center Transport Controls: Rewind 10s, Play/Pause, Forward 10s
        Row(
          modifier = Modifier.align(Alignment.Center),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(28.dp)
        ) {
          // 10s Rewind
          IconButton(
            onClick = { playerManager.rewind10Seconds() },
            modifier = Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.5f))
              .testTag("player_rewind_button")
          ) {
            Icon(Icons.Default.Replay10, contentDescription = "Rewind 10s", tint = Color.White, modifier = Modifier.size(28.dp))
          }

          // Play/Pause Main
          IconButton(
            onClick = { playerManager.togglePlayPause() },
            modifier = Modifier
              .size(64.dp)
              .clip(CircleShape)
              .background(CineRed)
              .testTag("player_play_pause_button")
          ) {
            Icon(
              imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = if (playerState.isPlaying) "Pause" else "Play",
              tint = Color.White,
              modifier = Modifier.size(36.dp)
            )
          }

          // 10s Forward
          IconButton(
            onClick = { playerManager.forward10Seconds() },
            modifier = Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.5f))
              .testTag("player_forward_button")
          ) {
            Icon(Icons.Default.Forward10, contentDescription = "Forward 10s", tint = Color.White, modifier = Modifier.size(28.dp))
          }
        }

        // Bottom Bar: Progress Slider & Time Labels
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter)
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
          val currentPos = playerState.currentPosition.toFloat()
          val duration = playerState.duration.coerceAtLeast(1L).toFloat()

          Slider(
            value = currentPos.coerceIn(0f, duration),
            onValueChange = { newPos ->
              playerManager.seekTo(newPos.toLong())
            },
            valueRange = 0f..duration,
            colors = SliderDefaults.colors(
              thumbColor = CineRed,
              activeTrackColor = CineRed,
              inactiveTrackColor = Color.White.copy(alpha = 0.3f)
            ),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("player_seek_bar")
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = formatTime(playerState.currentPosition),
              color = Color.White,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
            Text(
              text = formatTime(playerState.duration),
              color = CineTextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }
    }
  }
}

private fun formatTime(millis: Long): String {
  val totalSeconds = millis / 1000
  val minutes = totalSeconds / 60
  val seconds = totalSeconds % 60
  val hours = minutes / 60
  return if (hours > 0) {
    String.format("%d:%02d:%02d", hours, minutes % 60, seconds)
  } else {
    String.format("%02d:%02d", minutes, seconds)
  }
}
