package com.aistudio.cinenova.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.model.Movie
import com.aistudio.cinenova.app.ui.theme.*

@Composable
fun MovieCard(
  movie: Movie,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  cardWidth: Dp = 140.dp,
  cardHeight: Dp = 210.dp
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
    modifier = modifier
      .width(cardWidth)
      .testTag("movie_card_${movie.movieId}")
      .clip(RoundedCornerShape(12.dp))
      .clickable { onClick() }
  ) {
    Column {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(cardHeight)
      ) {
        AsyncImage(
          model = ImageRequest.Builder(LocalContext.current)
            .data(movie.poster)
            .crossfade(true)
            .build(),
          contentDescription = movie.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay at bottom of poster
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .align(Alignment.BottomCenter)
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, CineDarkSurface.copy(alpha = 0.95f))
              )
            )
        )

        // Rating Badge
        if (movie.rating > 0) {
          Row(
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(6.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(Color.Black.copy(alpha = 0.75f))
              .padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Star,
              contentDescription = "Rating",
              tint = CineGold,
              modifier = Modifier.size(12.dp)
            )
            Text(
              text = String.format("%.1f", movie.rating),
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp
            )
          }
        }

        // Category Tag at bottom left of image
        Text(
          text = movie.category,
          color = CineGoldLight,
          fontWeight = FontWeight.SemiBold,
          fontSize = 11.sp,
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(horizontal = 8.dp, vertical = 6.dp)
        )
      }

      // Title & Year
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(8.dp)
      ) {
        Text(
          text = movie.title,
          color = CineTextPrimary,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${movie.year}",
            color = CineTextSecondary,
            fontSize = 11.sp
          )
          Text(
            text = movie.duration,
            color = CineTextMuted,
            fontSize = 11.sp
          )
        }
      }
    }
  }
}
