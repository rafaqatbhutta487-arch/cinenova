package com.aistudio.cinenova.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.ui.theme.*

@Composable
fun CineTopBar(
  coinBalance: Long,
  onCoinClick: () -> Unit,
  onSearchClick: () -> Unit,
  onUploadClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = CineDarkBackground.copy(alpha = 0.95f),
    tonalElevation = 4.dp,
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // CineNova Brand Title
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Box(
          modifier = Modifier
            .size(30.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
              Brush.linearGradient(
                listOf(CineRed, Color(0xFF990000))
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "C",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 18.sp
          )
        }

        Text(
          text = "CineNova",
          color = Color.White,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 20.sp,
          letterSpacing = 0.5.sp
        )
      }

      // Action items: Coin Badge, Upload, Search
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Coin Badge
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = CineDarkSurfaceVariant,
          modifier = Modifier
            .testTag("coin_balance_badge")
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, CineGold.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .clickable { onCoinClick() }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.MonetizationOn,
              contentDescription = "Coins",
              tint = CineGold,
              modifier = Modifier.size(16.dp)
            )
            Text(
              text = "$coinBalance",
              color = CineGoldLight,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }

        // Upload Video Button
        IconButton(
          onClick = onUploadClick,
          modifier = Modifier
            .size(36.dp)
            .testTag("top_upload_button")
        ) {
          Icon(
            imageVector = Icons.Default.VideoCall,
            contentDescription = "Upload Content",
            tint = CineTextPrimary
          )
        }

        // Search Button
        IconButton(
          onClick = onSearchClick,
          modifier = Modifier
            .size(36.dp)
            .testTag("top_search_button")
        ) {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search",
            tint = CineTextPrimary
          )
        }
      }
    }
  }
}
