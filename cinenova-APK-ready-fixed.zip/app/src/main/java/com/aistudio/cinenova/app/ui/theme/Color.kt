package com.aistudio.cinenova.app.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic brand colors
val CineRed = Color(0xFFE50914)
val CineRedLight = Color(0xFFFF3342)
val CineGold = Color(0xFFFFB800)
val CineGoldLight = Color(0xFFFFD54F)

// Deep cinema dark theme colors
val CineDarkBackground = Color(0xFF080B11)
val CineDarkSurface = Color(0xFF101522)
val CineDarkSurfaceVariant = Color(0xFF182033)
val CineCardBorder = Color(0xFF232D44)

// Neutral text & accents
val CineTextPrimary = Color(0xFFF5F7FA)
val CineTextSecondary = Color(0xFFA0ABC0)
val CineTextMuted = Color(0xFF64748B)

val CineSuccess = Color(0xFF10B981)
val CineError = Color(0xFFEF4444)
val CineInfo = Color(0xFF3B82F6)
