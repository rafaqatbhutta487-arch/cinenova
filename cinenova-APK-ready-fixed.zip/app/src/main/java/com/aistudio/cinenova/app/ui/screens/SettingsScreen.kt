package com.aistudio.cinenova.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.data.repository.AuthRepository
import com.aistudio.cinenova.app.ui.theme.*

@Composable
fun SettingsScreen(
  authRepository: AuthRepository,
  onBackClick: () -> Unit
) {
  val currentUser by authRepository.currentUser.collectAsState()

  var autoResumePlayback by remember { mutableStateOf(true) }
  var streamQualityHd by remember { mutableStateOf(true) }
  var notifyNewReleases by remember { mutableStateOf(true) }
  var notifyTaskRewards by remember { mutableStateOf(true) }

  var activePolicyDialogTitle by remember { mutableStateOf<String?>(null) }
  var activePolicyDialogBody by remember { mutableStateOf<String?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .statusBarsPadding()
      .testTag("settings_screen")
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClick) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "Settings & Legal",
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
      )
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 8.dp)
        .padding(bottom = 40.dp),
      verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      // Account Info Card
      SettingsSection(title = "Account Details") {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          DetailRow(label = "Name", value = currentUser?.name ?: "User")
          DetailRow(label = "Email", value = currentUser?.email ?: "Not connected")
          DetailRow(label = "User ID", value = currentUser?.userId ?: "Guest")
          DetailRow(label = "Account Status", value = "Verified Streamer")
        }
      }

      // Playback Preferences
      SettingsSection(title = "Playback Preferences") {
        Column {
          ToggleRow(
            icon = Icons.Default.HighQuality,
            title = "Prefer High Definition (1080p)",
            subtitle = "Streams in highest available resolution over Wi-Fi/Mobile",
            checked = streamQualityHd,
            onCheckedChange = { streamQualityHd = it }
          )
          HorizontalDivider(color = CineCardBorder)
          ToggleRow(
            icon = Icons.Default.Restore,
            title = "Auto-Resume Playback",
            subtitle = "Automatically resume videos from saved timestamps",
            checked = autoResumePlayback,
            onCheckedChange = { autoResumePlayback = it }
          )
        }
      }

      // Notification Preferences
      SettingsSection(title = "Notifications") {
        Column {
          ToggleRow(
            icon = Icons.Default.NotificationsActive,
            title = "New Movie & Shorts Releases",
            subtitle = "Get alerted when new premier movies arrive",
            checked = notifyNewReleases,
            onCheckedChange = { notifyNewReleases = it }
          )
          HorizontalDivider(color = CineCardBorder)
          ToggleRow(
            icon = Icons.Default.MonetizationOn,
            title = "Coin Tasks & Daily Rewards",
            subtitle = "Reminders to claim daily viewing tasks and rewards",
            checked = notifyTaskRewards,
            onCheckedChange = { notifyTaskRewards = it }
          )
        }
      }

      // Legal & Compliance
      SettingsSection(title = "Legal & Content Compliance") {
        Column {
          SettingsNavRow(
            icon = Icons.Default.Description,
            title = "Terms of Service",
            onClick = {
              activePolicyDialogTitle = "Terms of Service"
              activePolicyDialogBody = """
                Welcome to CineNova. By accessing or using our streaming services, you agree to comply with our Terms of Service.
                
                1. Streaming License: Content is licensed for personal, non-commercial entertainment viewing only.
                2. User Uploads: When you upload content, you warrant that you hold all intellectual property rights and necessary licenses.
                3. Rewards Program: CineNova virtual coins are non-monetary digital tokens awarded for community engagement and promotional viewing. They carry no real-world cash exchange value.
                4. Anti-Abuse: Any automated bots, scripts, or fraudulent activity to accumulate coins will result in immediate account termination.
              """.trimIndent()
            }
          )
          HorizontalDivider(color = CineCardBorder)
          SettingsNavRow(
            icon = Icons.Default.PrivacyTip,
            title = "Privacy Policy",
            onClick = {
              activePolicyDialogTitle = "Privacy Policy"
              activePolicyDialogBody = """
                Your privacy is paramount at CineNova.
                
                1. Information Collected: Account email, profile name, watch history, and coin ledger transactions to provide tailored streaming and rewards.
                2. Data Protection: All data is encrypted in transit and at rest using modern cloud infrastructure.
                3. Third-Party Sharing: We do not sell or monetize personal user data with advertisers.
                4. Deletion: Users can request complete erasure of their account and viewing history at any time.
              """.trimIndent()
            }
          )
          HorizontalDivider(color = CineCardBorder)
          SettingsNavRow(
            icon = Icons.Default.Copyright,
            title = "DMCA & Copyright Policy",
            onClick = {
              activePolicyDialogTitle = "DMCA & Copyright Policy"
              activePolicyDialogBody = """
                CineNova strictly adheres to copyright protection laws including the Digital Millennium Copyright Act (DMCA).
                
                1. Copyright Infringement Reporting: If you believe your copyrighted work has been uploaded without authorization, please use the in-app "Report" tool on the video page or contact dmca@cinenova.stream.
                2. Content Removal: We investigate and promptly remove unauthorized infringing materials.
                3. Repeat Infringer Policy: CineNova maintains a strict termination policy for users who repeatedly infringe intellectual property rights.
              """.trimIndent()
            }
          )
        }
      }

      // About CineNova
      SettingsSection(title = "About Application") {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(text = "CineNova Streaming", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          Text(text = "Version: 1.0.0 (Production User Build)", color = CineTextSecondary, fontSize = 12.sp)
          Text(
            text = "Architecture: Client-Facing Streaming App powered by Firebase Authentication, Firestore DB, Firebase Storage & Media3 ExoPlayer.",
            color = CineTextMuted,
            fontSize = 12.sp,
            lineHeight = 18.sp
          )
          Spacer(modifier = Modifier.height(4.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = CineDarkSurfaceVariant,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "Note: CineNova is strictly the user-facing application. Administrative controls, video curation, and campaign management are maintained through the external CineNova Admin Suite.",
              color = CineGoldLight,
              fontSize = 11.sp,
              lineHeight = 16.sp,
              modifier = Modifier.padding(10.dp)
            )
          }
        }
      }
    }
  }

  // Policy Modal
  if (activePolicyDialogTitle != null) {
    AlertDialog(
      onDismissRequest = { activePolicyDialogTitle = null },
      containerColor = CineDarkSurface,
      title = { Text(activePolicyDialogTitle!!, color = Color.White, fontWeight = FontWeight.Bold) },
      text = {
        Text(
          text = activePolicyDialogBody ?: "",
          color = CineTextSecondary,
          fontSize = 13.sp,
          lineHeight = 19.sp
        )
      },
      confirmButton = {
        Button(
          onClick = { activePolicyDialogTitle = null },
          colors = ButtonDefaults.buttonColors(containerColor = CineRed)
        ) {
          Text("Close", color = Color.White)
        }
      }
    )
  }
}

@Composable
private fun SettingsSection(
  title: String,
  content: @Composable () -> Unit
) {
  Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    Text(
      text = title,
      color = CineTextSecondary,
      fontWeight = FontWeight.Bold,
      fontSize = 12.sp,
      modifier = Modifier.padding(horizontal = 4.dp)
    )
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      content()
    }
  }
}

@Composable
private fun DetailRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, color = CineTextSecondary, fontSize = 13.sp)
    Text(text = value, color = CineTextPrimary, fontWeight = FontWeight.Medium, fontSize = 13.sp)
  }
}

@Composable
private fun ToggleRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(14.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Icon(imageVector = icon, contentDescription = null, tint = CineGold, modifier = Modifier.size(22.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(text = title, color = CineTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
      Text(text = subtitle, color = CineTextMuted, fontSize = 11.sp)
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = CineRed,
        uncheckedThumbColor = CineTextMuted,
        uncheckedTrackColor = CineDarkSurfaceVariant
      )
    )
  }
}

@Composable
private fun SettingsNavRow(
  icon: ImageVector,
  title: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .padding(14.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Icon(imageVector = icon, contentDescription = null, tint = CineTextSecondary, modifier = Modifier.size(20.dp))
    Text(text = title, color = CineTextPrimary, fontWeight = FontWeight.Medium, fontSize = 14.sp, modifier = Modifier.weight(1f))
    Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, contentDescription = null, tint = CineTextMuted, modifier = Modifier.size(12.dp))
  }
}
