package com.aistudio.cinenova.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aistudio.cinenova.app.data.model.User
import com.aistudio.cinenova.app.data.repository.AuthRepository
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
  authRepository: AuthRepository,
  repository: CineNovaRepository,
  onOpenMovie: (String) -> Unit = {},
  onOpenWatchlist: () -> Unit,
  onOpenWatchHistory: () -> Unit,
  onOpenCoinHistory: () -> Unit,
  onOpenUploadVideo: () -> Unit,
  onOpenSettings: () -> Unit,
  onLogout: () -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val currentUser by authRepository.currentUser.collectAsState()
  val coinBalance by repository.coinBalance.collectAsState()
  val watchlist by repository.watchlist.collectAsState()
  val watchHistory by repository.watchHistory.collectAsState()
  val userLikes by repository.userLikes.collectAsState()
  val allMovies by repository.movies.collectAsState()
  val allShorts by repository.shorts.collectAsState()
  val myUploadedMovies = remember(allMovies, currentUser) {
    currentUser?.let { u -> allMovies.filter { it.uploaderId == u.userId } } ?: emptyList()
  }
  val myUploadedShorts = remember(allShorts, currentUser) {
    currentUser?.let { u -> allShorts.filter { it.creatorId == u.userId } } ?: emptyList()
  }

  var showLogoutConfirm by remember { mutableStateOf(false) }
  var showEditProfileDialog by remember { mutableStateOf(false) }
  var editName by remember { mutableStateOf("") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .verticalScroll(rememberScrollState())
      .testTag("profile_screen")
      .padding(horizontal = 16.dp, vertical = 12.dp)
      .padding(bottom = 100.dp)
  ) {
    Text(
      text = "My Profile",
      color = CineTextPrimary,
      fontWeight = FontWeight.Black,
      fontSize = 24.sp,
      modifier = Modifier.padding(bottom = 16.dp)
    )

    // User Info Header Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // User Avatar
        val avatarUrl = currentUser?.profileImage
        if (!avatarUrl.isNullOrEmpty()) {
          AsyncImage(
            model = ImageRequest.Builder(context)
              .data(avatarUrl)
              .crossfade(true)
              .build(),
            contentDescription = "Profile Photo",
            modifier = Modifier
              .size(64.dp)
              .clip(CircleShape)
          )
        } else {
          Box(
            modifier = Modifier
              .size(64.dp)
              .clip(CircleShape)
              .background(CineRed),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = (currentUser?.name?.take(1) ?: "U").uppercase(),
              color = Color.White,
              fontWeight = FontWeight.Black,
              fontSize = 26.sp
            )
          }
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = currentUser?.name ?: "CineNova Member",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
          )
          Text(
            text = currentUser?.email ?: "",
            color = CineTextSecondary,
            fontSize = 13.sp
          )
          Spacer(modifier = Modifier.height(4.dp))
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = CineDarkSurfaceVariant
          ) {
            Text(
              text = "PRO STREAMER",
              color = CineGoldLight,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        IconButton(
          onClick = {
            editName = currentUser?.name ?: ""
            showEditProfileDialog = true
          }
        ) {
          Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = CineTextSecondary)
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Quick Stats Card (Coins, Watchlist count, Watched count, Likes)
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CineDarkSurfaceVariant),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
      ) {
        StatItem(
          label = "Coins",
          value = "${coinBalance.balance}",
          icon = Icons.Default.MonetizationOn,
          color = CineGold,
          onClick = onOpenCoinHistory
        )
        StatItem(
          label = "Watchlist",
          value = "${watchlist.size}",
          icon = Icons.Default.Bookmark,
          color = CineRed,
          onClick = onOpenWatchlist
        )
        StatItem(
          label = "History",
          value = "${watchHistory.size}",
          icon = Icons.Default.History,
          color = CineTextPrimary,
          onClick = onOpenWatchHistory
        )
        StatItem(
          label = "Likes",
          value = "${userLikes.size}",
          icon = Icons.Default.Favorite,
          color = CineRed,
          onClick = {}
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // My Uploads Section - videos this user has published, always visible
    // here so they can track their own uploaded content.
    Text(
      text = "My Uploads (${myUploadedMovies.size + myUploadedShorts.size})",
      color = CineTextSecondary,
      fontWeight = FontWeight.Bold,
      fontSize = 13.sp,
      modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
    )

    if (myUploadedMovies.isEmpty() && myUploadedShorts.isEmpty()) {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = CineTextMuted, modifier = Modifier.size(32.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "You haven't uploaded anything yet",
            color = CineTextSecondary,
            fontSize = 13.sp
          )
          TextButton(onClick = onOpenUploadVideo) {
            Text("Upload your first video", color = CineRed, fontWeight = FontWeight.Bold)
          }
        }
      }
    } else {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(myUploadedMovies, key = { "m_${it.movieId}" }) { m ->
          MyUploadCard(
            thumbnail = m.poster,
            title = m.title,
            badge = "Movie",
            views = m.views,
            onClick = { onOpenMovie(m.movieId) }
          )
        }
        items(myUploadedShorts, key = { "s_${it.shortId}" }) { s ->
          MyUploadCard(
            thumbnail = s.thumbnail,
            title = s.title,
            badge = "Short",
            views = s.views,
            onClick = {
              Toast.makeText(context, "Open the Shorts tab to watch this", Toast.LENGTH_SHORT).show()
            }
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Content & Library",
      color = CineTextSecondary,
      fontWeight = FontWeight.Bold,
      fontSize = 13.sp,
      modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
    )

    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column {
        ProfileNavRow(
          icon = Icons.Default.BookmarkBorder,
          title = "Watchlist",
          subtitle = "${watchlist.size} saved movies",
          onClick = onOpenWatchlist
        )
        HorizontalDivider(color = CineCardBorder)
        ProfileNavRow(
          icon = Icons.Default.History,
          title = "Watch History",
          subtitle = "Continue watching recent titles",
          onClick = onOpenWatchHistory
        )
        HorizontalDivider(color = CineCardBorder)
        ProfileNavRow(
          icon = Icons.Default.VideoCall,
          title = "Upload Movie or Short",
          subtitle = "Publish creator content to CineNova",
          iconTint = CineRed,
          onClick = onOpenUploadVideo
        )
        HorizontalDivider(color = CineCardBorder)
        ProfileNavRow(
          icon = Icons.Default.MonetizationOn,
          title = "Coin Transactions",
          subtitle = "Detailed earnings and rewards ledger",
          iconTint = CineGold,
          onClick = onOpenCoinHistory
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Preferences & Support",
      color = CineTextSecondary,
      fontWeight = FontWeight.Bold,
      fontSize = 13.sp,
      modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
    )

    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column {
        ProfileNavRow(
          icon = Icons.Default.Settings,
          title = "App Settings & Policies",
          subtitle = "Streaming quality, DMCA, Privacy, Terms",
          onClick = onOpenSettings
        )
        HorizontalDivider(color = CineCardBorder)
        ProfileNavRow(
          icon = Icons.AutoMirrored.Filled.Logout,
          title = "Sign Out",
          subtitle = "Log out from this device",
          iconTint = CineError,
          onClick = { showLogoutConfirm = true }
        )
      }
    }
  }

  // Edit Profile Dialog
  if (showEditProfileDialog) {
    AlertDialog(
      onDismissRequest = { showEditProfileDialog = false },
      containerColor = CineDarkSurface,
      title = { Text("Edit Profile", color = Color.White, fontWeight = FontWeight.Bold) },
      text = {
        Column {
          OutlinedTextField(
            value = editName,
            onValueChange = { editName = it },
            label = { Text("Display Name") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = CineRed,
              unfocusedBorderColor = CineCardBorder,
              focusedTextColor = CineTextPrimary,
              unfocusedTextColor = CineTextPrimary,
              focusedContainerColor = CineDarkSurfaceVariant,
              unfocusedContainerColor = CineDarkSurfaceVariant
            ),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (editName.isNotBlank()) {
              scope.launch {
                authRepository.updateProfile(editName.trim(), null)
                showEditProfileDialog = false
                Toast.makeText(context, "Profile updated", Toast.LENGTH_SHORT).show()
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = CineRed)
        ) {
          Text("Save", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditProfileDialog = false }) {
          Text("Cancel", color = CineTextSecondary)
        }
      }
    )
  }

  // Logout Confirmation Dialog
  if (showLogoutConfirm) {
    AlertDialog(
      onDismissRequest = { showLogoutConfirm = false },
      containerColor = CineDarkSurface,
      title = { Text("Sign Out", color = Color.White, fontWeight = FontWeight.Bold) },
      text = {
        Text(
          "Are you sure you want to log out of CineNova?",
          color = CineTextSecondary,
          fontSize = 14.sp
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showLogoutConfirm = false
            authRepository.logout()
            onLogout()
          },
          colors = ButtonDefaults.buttonColors(containerColor = CineError)
        ) {
          Text("Log Out", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showLogoutConfirm = false }) {
          Text("Cancel", color = CineTextSecondary)
        }
      }
    )
  }
}

@Composable
private fun StatItem(
  label: String,
  value: String,
  icon: ImageVector,
  color: Color,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .clickable { onClick() }
      .padding(horizontal = 8.dp, vertical = 4.dp)
  ) {
    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    Text(text = label, color = CineTextMuted, fontSize = 11.sp)
  }
}

@Composable
private fun MyUploadCard(
  thumbnail: String,
  title: String,
  badge: String,
  views: Long,
  onClick: () -> Unit
) {
  Column(
    modifier = Modifier
      .width(120.dp)
      .clip(RoundedCornerShape(10.dp))
      .clickable { onClick() }
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(160.dp)
        .clip(RoundedCornerShape(10.dp))
        .background(CineDarkSurfaceVariant)
    ) {
      AsyncImage(
        model = thumbnail,
        contentDescription = title,
        modifier = Modifier.fillMaxSize()
      )
      Surface(
        shape = RoundedCornerShape(4.dp),
        color = CineRed,
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(6.dp)
      ) {
        Text(
          text = badge,
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 9.sp,
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
      }
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = title,
      color = CineTextPrimary,
      fontWeight = FontWeight.SemiBold,
      fontSize = 12.sp,
      maxLines = 1
    )
    Text(
      text = "$views views",
      color = CineTextMuted,
      fontSize = 10.sp
    )
  }
}

@Composable
private fun ProfileNavRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  iconTint: Color = CineTextPrimary,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .padding(16.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(22.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(text = title, color = CineTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
      Text(text = subtitle, color = CineTextSecondary, fontSize = 12.sp)
    }
    Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, contentDescription = null, tint = CineTextMuted, modifier = Modifier.size(14.dp))
  }
}
