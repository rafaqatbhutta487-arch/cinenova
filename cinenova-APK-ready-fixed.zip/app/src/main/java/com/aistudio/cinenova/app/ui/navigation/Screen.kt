package com.aistudio.cinenova.app.ui.navigation

sealed class Screen(val route: String) {
  object Splash : Screen("splash")
  object Auth : Screen("auth")
  object Main : Screen("main")
  object MovieDetail : Screen("movie_detail/{movieId}") {
    fun createRoute(movieId: String) = "movie_detail/$movieId"
  }
  object VideoPlayer : Screen("video_player/{movieId}") {
    fun createRoute(movieId: String) = "video_player/$movieId"
  }
  object PromotionPoster : Screen("promotion_poster")
  object Watchlist : Screen("watchlist")
  object WatchHistory : Screen("watch_history")
  object CoinHistory : Screen("coin_history")
  object UploadVideo : Screen("upload_video")
  object Search : Screen("search")
  object Settings : Screen("settings")
}

enum class BottomTab(val title: String, val route: String) {
  HOME("Home", "tab_home"),
  MOVIES("Movies", "tab_movies"),
  SHORTS("Shorts", "tab_shorts"),
  TASKS("Tasks", "tab_tasks"),
  PROFILE("Profile", "tab_profile")
}
