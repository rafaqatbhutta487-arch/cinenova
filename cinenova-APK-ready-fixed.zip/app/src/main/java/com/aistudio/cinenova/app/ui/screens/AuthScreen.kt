package com.aistudio.cinenova.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.data.repository.AuthRepository
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
  authRepository: AuthRepository,
  onAuthSuccess: () -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val focusManager = LocalFocusManager.current

  var isRegisterMode by remember { mutableStateOf(false) }
  var name by remember { mutableStateOf("") }
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var confirmPassword by remember { mutableStateOf("") }
  var passwordVisible by remember { mutableStateOf(false) }

  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var showForgotPasswordDialog by remember { mutableStateOf(false) }
  var resetEmail by remember { mutableStateOf("") }

  fun executeAuth() {
    focusManager.clearFocus()
    errorMessage = null

    if (isRegisterMode) {
      if (name.isBlank()) {
        errorMessage = "Please enter your name"
        return
      }
      if (email.isBlank()) {
        errorMessage = "Please enter your email"
        return
      }
      if (password.length < 6) {
        errorMessage = "Password must be at least 6 characters"
        return
      }
      if (password != confirmPassword) {
        errorMessage = "Passwords do not match"
        return
      }

      isLoading = true
      scope.launch {
        val result = authRepository.registerWithEmail(name.trim(), email.trim(), password)
        isLoading = false
        result.fold(
          onSuccess = {
            Toast.makeText(context, "Welcome to CineNova, ${it.name}!", Toast.LENGTH_SHORT).show()
            onAuthSuccess()
          },
          onFailure = {
            errorMessage = it.message ?: "Registration failed. Please try again."
          }
        )
      }
    } else {
      if (email.isBlank() || password.isBlank()) {
        errorMessage = "Please enter email and password"
        return
      }

      isLoading = true
      scope.launch {
        val result = authRepository.loginWithEmail(email.trim(), password)
        isLoading = false
        result.fold(
          onSuccess = {
            Toast.makeText(context, "Welcome back, ${it.name}!", Toast.LENGTH_SHORT).show()
            onAuthSuccess()
          },
          onFailure = {
            errorMessage = it.message ?: "Unable to sign in. Please verify credentials."
          }
        )
      }
    }
  }

  fun executeGoogleSignIn() {
    focusManager.clearFocus()
    errorMessage = null
    isLoading = true
    scope.launch {
      val result = authRepository.signInWithGoogle(context)
      isLoading = false
      result.fold(
        onSuccess = {
          Toast.makeText(context, "Signed in as ${it.name}", Toast.LENGTH_SHORT).show()
          onAuthSuccess()
        },
        onFailure = {
          // Provide friendly message if play services or google credentials not yet configured
          val msg = it.message ?: "Google Sign-In canceled"
          if (msg.contains("16") || msg.contains("canceled", ignoreCase = true)) {
            errorMessage = "Google sign-in was canceled or credentials not configured yet. You can sign in with email."
          } else {
            errorMessage = msg
          }
        }
      )
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .statusBarsPadding()
      .navigationBarsPadding()
      .imePadding()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp, vertical = 20.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(20.dp))

      // Logo Branding
      Box(
        modifier = Modifier
          .size(56.dp)
          .clip(RoundedCornerShape(16.dp))
          .background(
            Brush.linearGradient(
              listOf(CineRed, Color(0xFF8B0000))
            )
          ),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "C",
          color = Color.White,
          fontWeight = FontWeight.Black,
          fontSize = 32.sp
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = "CineNova",
        color = Color.White,
        fontWeight = FontWeight.Black,
        fontSize = 28.sp,
        letterSpacing = 0.5.sp
      )

      Text(
        text = if (isRegisterMode) "Create your stream account" else "Sign in to continue watching",
        color = CineTextSecondary,
        fontSize = 14.sp
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Mode Switcher Tabs
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = CineDarkSurface,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (!isRegisterMode) CineRed else Color.Transparent)
              .clickable {
                isRegisterMode = false
                errorMessage = null
              }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Sign In",
              color = if (!isRegisterMode) Color.White else CineTextSecondary,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }

          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (isRegisterMode) CineRed else Color.Transparent)
              .clickable {
                isRegisterMode = true
                errorMessage = null
              }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Create Account",
              color = if (isRegisterMode) Color.White else CineTextSecondary,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Error banner
      if (errorMessage != null) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = CineError.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(1.dp, CineError.copy(alpha = 0.4f)),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("auth_error_banner")
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = CineError)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = errorMessage!!, color = CineError, fontSize = 13.sp)
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
      }

      // Input Fields
      if (isRegisterMode) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Full Name") },
          leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CineTextSecondary) },
          singleLine = true,
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CineRed,
            unfocusedBorderColor = CineCardBorder,
            focusedTextColor = CineTextPrimary,
            unfocusedTextColor = CineTextPrimary,
            focusedContainerColor = CineDarkSurface,
            unfocusedContainerColor = CineDarkSurface
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("name_input")
        )
        Spacer(modifier = Modifier.height(12.dp))
      }

      OutlinedTextField(
        value = email,
        onValueChange = { email = it },
        label = { Text("Email / Gmail") },
        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CineTextSecondary) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = CineRed,
          unfocusedBorderColor = CineCardBorder,
          focusedTextColor = CineTextPrimary,
          unfocusedTextColor = CineTextPrimary,
          focusedContainerColor = CineDarkSurface,
          unfocusedContainerColor = CineDarkSurface
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("email_input")
      )

      Spacer(modifier = Modifier.height(12.dp))

      OutlinedTextField(
        value = password,
        onValueChange = { password = it },
        label = { Text("Password") },
        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = CineTextSecondary) },
        trailingIcon = {
          IconButton(onClick = { passwordVisible = !passwordVisible }) {
            Icon(
              imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
              contentDescription = "Toggle password",
              tint = CineTextSecondary
            )
          }
        },
        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = if (isRegisterMode) ImeAction.Next else ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { executeAuth() }),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = CineRed,
          unfocusedBorderColor = CineCardBorder,
          focusedTextColor = CineTextPrimary,
          unfocusedTextColor = CineTextPrimary,
          focusedContainerColor = CineDarkSurface,
          unfocusedContainerColor = CineDarkSurface
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("password_input")
      )

      if (isRegisterMode) {
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
          value = confirmPassword,
          onValueChange = { confirmPassword = it },
          label = { Text("Confirm Password") },
          leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = CineTextSecondary) },
          visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
          keyboardActions = KeyboardActions(onDone = { executeAuth() }),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CineRed,
            unfocusedBorderColor = CineCardBorder,
            focusedTextColor = CineTextPrimary,
            unfocusedTextColor = CineTextPrimary,
            focusedContainerColor = CineDarkSurface,
            unfocusedContainerColor = CineDarkSurface
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("confirm_password_input")
        )
      }

      if (!isRegisterMode) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
          horizontalArrangement = Arrangement.End
        ) {
          TextButton(
            onClick = {
              resetEmail = email
              showForgotPasswordDialog = true
            }
          ) {
            Text(text = "Forgot password?", color = CineGoldLight, fontSize = 13.sp)
          }
        }
      } else {
        Spacer(modifier = Modifier.height(12.dp))
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Primary Submit Button
      Button(
        onClick = { executeAuth() },
        enabled = !isLoading,
        colors = ButtonDefaults.buttonColors(containerColor = CineRed),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("auth_submit_button")
      ) {
        if (isLoading) {
          CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
        } else {
          Text(
            text = if (isRegisterMode) "Create Account" else "Sign In",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Divider OR
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        HorizontalDivider(modifier = Modifier.weight(1f), color = CineCardBorder)
        Text(
          text = "OR",
          color = CineTextMuted,
          fontSize = 12.sp,
          modifier = Modifier.padding(horizontal = 12.dp)
        )
        HorizontalDivider(modifier = Modifier.weight(1f), color = CineCardBorder)
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Continue with Google Button
      OutlinedButton(
        onClick = { executeGoogleSignIn() },
        enabled = !isLoading,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.outlinedButtonColors(
          containerColor = CineDarkSurface,
          contentColor = CineTextPrimary
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, CineCardBorder),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("google_login_button")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          // Google G icon badge
          Box(
            modifier = Modifier
              .size(24.dp)
              .clip(CircleShape)
              .background(Color.White),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "G",
              color = Color(0xFF4285F4),
              fontWeight = FontWeight.Black,
              fontSize = 15.sp
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Continue with Google",
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
          )
        }
      }
    }
  }

  // Forgot password dialog
  if (showForgotPasswordDialog) {
    AlertDialog(
      onDismissRequest = { showForgotPasswordDialog = false },
      containerColor = CineDarkSurface,
      title = { Text("Reset Password", color = CineTextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text(
            "Enter your registered email address. We will send a secure password reset link to your inbox.",
            color = CineTextSecondary,
            fontSize = 13.sp
          )
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = resetEmail,
            onValueChange = { resetEmail = it },
            label = { Text("Email") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = CineRed,
              unfocusedBorderColor = CineCardBorder,
              focusedTextColor = CineTextPrimary,
              unfocusedTextColor = CineTextPrimary,
              focusedContainerColor = CineDarkSurfaceVariant,
              unfocusedContainerColor = CineDarkSurfaceVariant
            ),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (resetEmail.isNotBlank()) {
              scope.launch {
                val res = authRepository.resetPassword(resetEmail.trim())
                showForgotPasswordDialog = false
                res.fold(
                  onSuccess = {
                    Toast.makeText(context, "Password reset email sent!", Toast.LENGTH_LONG).show()
                  },
                  onFailure = {
                    Toast.makeText(context, it.message ?: "Failed to send reset email", Toast.LENGTH_SHORT).show()
                  }
                )
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = CineRed)
        ) {
          Text("Send Link", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showForgotPasswordDialog = false }) {
          Text("Cancel", color = CineTextSecondary)
        }
      }
    )
  }
}
