package com.aistudio.cinenova.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.data.model.TaskCompletion
import com.aistudio.cinenova.app.data.model.TaskItem
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun TasksScreen(
  repository: CineNovaRepository,
  currentUserId: String,
  onOpenPromoCampaign: () -> Unit,
  onOpenCoinHistory: () -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val coinBalance by repository.coinBalance.collectAsState()
  val tasks by repository.tasks.collectAsState()
  val taskCompletions by repository.taskCompletions.collectAsState()

  val todayKey = remember { repository.getTodayDateKey() }

  // Auto-record login task progress once on opening Tasks tab
  LaunchedEffect(todayKey) {
    repository.recordTaskProgress(currentUserId, "task_daily_login", 1)
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .testTag("tasks_screen"),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Hero: Coin Balance & Daily Limit Status
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CineGold.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "CineNova Balance",
                color = CineTextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
              )
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.MonetizationOn,
                  contentDescription = null,
                  tint = CineGold,
                  modifier = Modifier.size(28.dp)
                )
                Text(
                  text = "${coinBalance.balance}",
                  color = Color.White,
                  fontWeight = FontWeight.Black,
                  fontSize = 32.sp
                )
                Text(
                  text = "Coins",
                  color = CineGoldLight,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp
                )
              }
            }

            OutlinedButton(
              onClick = onOpenCoinHistory,
              colors = ButtonDefaults.outlinedButtonColors(contentColor = CineGoldLight),
              border = androidx.compose.foundation.BorderStroke(1.dp, CineGold.copy(alpha = 0.5f)),
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.testTag("view_coin_history_button")
            ) {
              Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("History", fontSize = 12.sp)
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          HorizontalDivider(color = CineCardBorder)
          Spacer(modifier = Modifier.height(12.dp))

          // Daily Earning Limit Progress
          val dailyLimit = 1000L
          val dailyRatio = (coinBalance.dailyEarned.toFloat() / dailyLimit.toFloat()).coerceIn(0f, 1f)

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Daily Earning Limit",
              color = CineTextSecondary,
              fontSize = 12.sp
            )
            Text(
              text = "${coinBalance.dailyEarned} / $dailyLimit Coins",
              color = if (coinBalance.dailyEarned >= dailyLimit) CineError else CineGoldLight,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          LinearProgressIndicator(
            progress = { dailyRatio },
            color = if (coinBalance.dailyEarned >= dailyLimit) CineError else CineGold,
            trackColor = CineDarkSurfaceVariant,
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp))
          )

          if (coinBalance.dailyEarned >= dailyLimit) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Daily coin limit reached. Come back tomorrow!",
              color = CineError,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }
    }

    // Featured Poster Promotion Showcase Task Banner
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CineDarkSurfaceVariant),
        border = androidx.compose.foundation.BorderStroke(1.dp, CineRed.copy(alpha = 0.5f)),
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .clickable { onOpenPromoCampaign() }
          .testTag("promo_campaign_card")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(
                Brush.linearGradient(
                  listOf(CineRed, Color(0xFF990000))
                )
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Campaign, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
          }

          Column(modifier = Modifier.weight(1f)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Surface(color = CineRed, shape = RoundedCornerShape(4.dp)) {
                Text(
                  text = "EXCLUSIVE PROMO",
                  color = Color.White,
                  fontWeight = FontWeight.Black,
                  fontSize = 9.sp,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
              Text(
                text = "+100 Coins",
                color = CineGold,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Premiere Gala Showcase",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
            Text(
              text = "View the official CineNova Gala promotional poster for 30s.",
              color = CineTextSecondary,
              fontSize = 11.sp,
              maxLines = 1
            )
          }

          Icon(Icons.Default.ChevronRight, contentDescription = null, tint = CineGoldLight)
        }
      }
    }

    // Daily Tasks Header
    item {
      Text(
        text = "Daily Earning Tasks",
        color = CineTextPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        modifier = Modifier.padding(top = 8.dp)
      )
    }

    // Daily Tasks List
    items(tasks, key = { it.taskId }) { task ->
      val completionKey = "${currentUserId}_${task.taskId}_$todayKey"
      val completion = taskCompletions[completionKey] ?: TaskCompletion(
        completionId = completionKey,
        userId = currentUserId,
        taskId = task.taskId,
        date = todayKey
      )

      TaskRowItem(
        task = task,
        completion = completion,
        onClaim = {
          scope.launch {
            val result = repository.claimTaskReward(currentUserId, task.taskId)
            result.fold(
              onSuccess = { awarded ->
                Toast.makeText(context, "+$awarded CineNova Coins Awarded!", Toast.LENGTH_SHORT).show()
              },
              onFailure = { error ->
                Toast.makeText(context, error.message ?: "Claim failed", Toast.LENGTH_SHORT).show()
              }
            )
          }
        },
        onActionClick = {
          if (task.taskId == "task_promo_poster") {
            onOpenPromoCampaign()
          }
        }
      )
    }
  }
}

@Composable
private fun TaskRowItem(
  task: TaskItem,
  completion: TaskCompletion,
  onClaim: () -> Unit,
  onActionClick: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = CineDarkSurface),
    border = androidx.compose.foundation.BorderStroke(
      1.dp,
      if (completion.completed && !completion.claimed) CineGold.copy(alpha = 0.6f) else CineCardBorder
    ),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Icon representation based on task type
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(
            if (completion.claimed) CineDarkSurfaceVariant
            else if (completion.completed) CineGold.copy(alpha = 0.2f)
            else CineRed.copy(alpha = 0.2f)
          ),
        contentAlignment = Alignment.Center
      ) {
        val icon = when (task.targetType) {
          "login" -> Icons.Default.CheckCircle
          "watch_movie" -> Icons.Default.Movie
          "watch_short" -> Icons.Default.PlayCircleFilled
          else -> Icons.Default.Campaign
        }
        val tint = if (completion.claimed) CineTextMuted else if (completion.completed) CineGold else CineRed
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
      }

      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = task.title,
            color = CineTextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = CineDarkSurfaceVariant
          ) {
            Text(
              text = "+${task.reward} Coins",
              color = CineGoldLight,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = task.description,
          color = CineTextSecondary,
          fontSize = 11.sp,
          lineHeight = 16.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Progress text
        val current = completion.currentProgress.coerceAtMost(task.targetCount)
        Text(
          text = "Progress: $current / ${task.targetCount}",
          color = if (completion.completed) CineGoldLight else CineTextMuted,
          fontSize = 10.sp,
          fontWeight = FontWeight.Medium
        )
      }

      // Claim or Action Button
      if (completion.claimed) {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = CineDarkSurfaceVariant
        ) {
          Text(
            text = "Claimed",
            color = CineTextMuted,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          )
        }
      } else if (completion.completed) {
        Button(
          onClick = onClaim,
          colors = ButtonDefaults.buttonColors(containerColor = CineGold),
          shape = RoundedCornerShape(16.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
          modifier = Modifier.testTag("claim_button_${task.taskId}")
        ) {
          Text(
            text = "Claim",
            color = Color.Black,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
          )
        }
      } else {
        if (task.taskId == "task_promo_poster") {
          OutlinedButton(
            onClick = onActionClick,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CineCardBorder),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
          ) {
            Text("Open", color = CineTextSecondary, fontSize = 12.sp)
          }
        } else {
          Text(
            text = "In Progress",
            color = CineTextMuted,
            fontSize = 11.sp
          )
        }
      }
    }
  }
}
