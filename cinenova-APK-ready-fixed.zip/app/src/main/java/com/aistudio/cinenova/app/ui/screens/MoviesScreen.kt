package com.aistudio.cinenova.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.cinenova.app.data.repository.CineNovaRepository
import com.aistudio.cinenova.app.ui.components.MovieCard
import com.aistudio.cinenova.app.ui.theme.*

@Composable
fun MoviesScreen(
  repository: CineNovaRepository,
  onMovieClick: (String) -> Unit
) {
  val movies by repository.movies.collectAsState()
  var selectedCategory by remember { mutableStateOf("All") }

  val filteredMovies = remember(movies, selectedCategory) {
    if (selectedCategory == "All") movies else movies.filter { it.category.equals(selectedCategory, ignoreCase = true) }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CineDarkBackground)
      .testTag("movies_screen")
  ) {
    // Top Title & Filter Summary
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Browse Movies",
        color = CineTextPrimary,
        fontWeight = FontWeight.Black,
        fontSize = 22.sp
      )

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Icon(Icons.Default.FilterList, contentDescription = null, tint = CineGold, modifier = Modifier.size(16.dp))
        Text(
          text = "${filteredMovies.size} titles",
          color = CineTextSecondary,
          fontSize = 13.sp
        )
      }
    }

    // Horizontal category chips
    LazyRow(
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.padding(bottom = 12.dp)
    ) {
      items(repository.categories) { category ->
        val isSelected = category == selectedCategory
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = if (isSelected) CineRed else CineDarkSurface,
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) CineRed else CineCardBorder
          ),
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable { selectedCategory = category }
        ) {
          Text(
            text = category,
            color = if (isSelected) Color.White else CineTextSecondary,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
          )
        }
      }
    }

    // Grid of Movies
    if (filteredMovies.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "No movies found for \"$selectedCategory\"",
          color = CineTextMuted,
          fontSize = 14.sp
        )
      }
    } else {
      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp, top = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(filteredMovies, key = { it.movieId }) { movie ->
          MovieCard(
            movie = movie,
            cardWidth = 170.dp,
            cardHeight = 230.dp,
            onClick = { onMovieClick(movie.movieId) },
            modifier = Modifier.fillMaxWidth()
          )
        }
      }
    }
  }
}
